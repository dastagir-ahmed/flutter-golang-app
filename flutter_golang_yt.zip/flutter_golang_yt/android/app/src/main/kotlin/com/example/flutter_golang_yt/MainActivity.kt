package com.example.flutter_golang_yt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
